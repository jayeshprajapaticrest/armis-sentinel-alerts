"""This __init__ file will be called once triggered is generated."""
import datetime
import logging
import azure.functions as func
import base64
import hashlib
import hmac
import json
import os
import requests
from .state_manager import StateManager
from Exceptions.ArmisExceptions import ArmisException

API_KEY = os.environ["ArmisSecretKey"]
url = os.environ["ArmisURL"]
connection_string = os.environ["AzureWebJobsStorage"]
customer_id = os.environ["WorkspaceID"]
shared_key = os.environ["WorkspaceKey"]
armis_alerts = os.environ["ArmisAlertsTableName"]

HTTP_ERRORS = {
    400: "Armis Alert Connecter: Bad request: Missing aql Parameter.",
    401: "Armis Alert Connecter: Authentication error: Authorization information is missing or invalid.",
}
ERROR_MESSAGES = {
    "ACCESS_TOKEN_NOT_FOUND": "Armis Alert Connecter: Access Token not found. Please check Key.",
    "HOST_CONNECTION_ERROR": "Armis Alert Connecter: Invalid host while verifying 'Armis Account'",
}
data_alert_from, retry_alert_token = 0, 1

body = ""


class ArmisAlert:
    """This class will process the Alert data and post it into the Azure sentinel."""

    def __init__(self):
        """This method will initialize object of class."""
        self._link = url
        self._header = {
            "Content-Type": "application/json",
        }
        self._secret_key = API_KEY

    def _get_access_token_alert(self, armis_link_suffix):
        """
        This method will fetch the access token using api and.
        set it in header for further use.

        Args:
            armis_link_suffix (String): This variable will be suffix/add-on to the link.

        """

        if self._secret_key is not None and self._link is not None:
            parameter = {"secret_key": self._secret_key}
            try:
                response = requests.post(
                    (self._link + armis_link_suffix), params=parameter
                )
                if response.status_code == 200:
                    logging.info("Armis Alert Connecter: Getting Access Token.")
                    _access_token = json.loads(response.text)["data"]["access_token"]
                    self._header.update({"Authorization": _access_token})
                elif response.status_code == 400:
                    raise ArmisException(
                        "Armis Alert Connecter: Bad request, please check the arguments you passed."
                    )

                else:
                    raise ArmisException(
                        "Armis Alert Connecter: Error while generating the access token. Error code: {}.".format(
                            response.status_code
                        )
                    )

            except ArmisException as err:
                logging.error(err)
                raise ArmisException(
                    "Armis Alert Connecter: Error while generating the access token."
                )

        else:
            raise ArmisException(
                "Armis Alert Connecter: The secret key or link has not been initialized."
            )

    def _get_alert_data(self, armis_link_suffix, parameter):
        """_get_alert_data is used to get data using api.

        Args:
            self: Armis object.
            armis_link_suffix (String): will be containing the other part of link.
            parameter (json): will contain the json data to sends to parameter to get data from REST API.

        """
        try:
            global data_alert_from, retry_alert_token

            response = requests.get(
                (self._link + armis_link_suffix), params=parameter, headers=self._header
            )
            if response.status_code == 200:
                logging.info(
                    "Armis Alert Connecter: Getting data with response code %s",
                    response.status_code,
                )
                results = json.loads(response.text)
                if (
                    "data" in results
                    and "results" in results["data"]
                    and "total" in results["data"]
                    and "count" in results["data"]
                    and "next" in results["data"]
                ):
                    total_data_length = results["data"]["total"]
                    count_per_frame_data = results["data"]["count"]
                    data = results["data"]["results"]

                    body = json.dumps(data, indent=2)
                    logging.info(
                        "Armis Alert Connecter: From this length %s we are fetching data.",
                        data_alert_from,
                    )
                    data_alert_from = results["data"]["next"]
                    logging.info(
                        "Armis Alert Connecter: Next page will be from %s",
                        data_alert_from,
                    )
                    current_time = data[-1]["time"][:-13]

                    return body, current_time, total_data_length, count_per_frame_data
                else:
                    raise ArmisException(
                        "Armis Alert Connecter: There are no proper keys in data."
                    )

            elif response.status_code == 400:
                raise ArmisException(HTTP_ERRORS[400])

            elif response.status_code == 401 and retry_alert_token <= 3:
                logging.info(
                    "Armis Alert Connecter: Retry number: {}".format(
                        str(retry_alert_token)
                    )
                )
                retry_alert_token += 1
                logging.error(HTTP_ERRORS[401])
                logging.info("Armis Alert Connecter: Generating Access Token Again!")
                self._get_access_token_alert("/access_token/")
                return self._get_alert_data(armis_link_suffix, parameter)
            else:
                raise ArmisException(
                    "Armis Alert Connecter: Error while fetching data. Status Code:{} Error Message:{}.".format(
                        response.status_code, response.text
                    )
                )

        except requests.exceptions.ConnectionError:
            logging.error(ERROR_MESSAGES["HOST_CONNECTION_ERROR"])
            raise ArmisException(
                "Armis Alert Connecter:Connection error while getting data from alert api."
            )

        except requests.exceptions.RequestException as request_err:
            logging.error(request_err)
            raise ArmisException(
                "Armis Alert Connecter:Request error while getting data from alert api."
            )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Alert Connecter: Error while getting data from alert api."
            )

    def _fetch_alert_data(
        self, type_data, state, table_name, is_table_not_exist, last_time=None
    ):
        """Fetch_alert_data is used to push all the data into table.

        Args:
            self: Armis object.
            type_data (json): will contain the json data to use in the _get_links function.
            state (object): StateManager object.
            table_name (String): table name to store the data in azure sentinel.
            is_table_not_exist (bool): it is a flag that contains the value if table exists or not.
            last_time (String): it will contain latest time stamp.
        """
        try:
            self._get_access_token_alert("/access_token/")
            if is_table_not_exist:
                aql_data = """{}""".format(type_data["aql"])
            else:
                aql_data = """{} after:{}""".format(type_data["aql"], last_time)
            type_data["aql"] = aql_data
            logging.info("Armis Alert Connecter: aql data new " + str(type_data["aql"]))

            azuresentinel = AzureSentinel()
            while data_alert_from is not None:
                parameter_alert = {
                    "aql": type_data["aql"],
                    "from": data_alert_from,
                    "orderBy": "time",
                    "length": 1000,
                    "fields": type_data["fields"],
                }
                (
                    body,
                    current_time,
                    total_data_length,
                    count_per_frame_data,
                ) = self._get_alert_data("/search/", parameter_alert)
                logging.info(
                    "Armis Alert Connecter: Total length of data is %s ",
                    total_data_length,
                )
                logging.info("Armis Alert Connecter: Data Gathered SuccessFully.")
                azuresentinel.post_data(customer_id, body, table_name)
                logging.info(
                    "Armis Alert Connecter: Collected %s data of %s into sentinel.",
                    count_per_frame_data,
                    type_data["aql"],
                )
                state.post(str(current_time))
                logging.info(
                    "Armis Alert Connecter: Time stamp added at: " + str(current_time)
                )
                logging.info(
                    "Armis Alert Connecter: StateManager Time_Data Posted Successfully!"
                )
        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Alert Connecter: Error while processing the data."
            )

    def check_data_exists_or_not_alert(self):
        """Check_data_exists_or_not is to check if the data is exists or not using the timestamp file.

        Args:
            self: Armis object.

        """
        try:
            parameter_alert = {
                "aql": "in:alerts",
                "orderBy": "time",
                "fields": "alertId,type,title,description,severity,time,status,deviceIds,activityUUIDs",
            }
            state_alerts = StateManager(
                connection_string=connection_string, file_path="funcarmisalertsfile"
            )
            last_time_alerts = state_alerts.get()
            if last_time_alerts is None:
                logging.info(
                    "Armis Alert Connecter: The last time point is not available in alerts!"
                )
                self._fetch_alert_data(
                    parameter_alert,
                    state_alerts,
                    armis_alerts,
                    True,
                    last_time_alerts,
                )
                logging.info(
                    "Armis Alert Connecter: Data added when no logs was there."
                )
            else:
                logging.info(
                    "Armis Alert Connecter: The last time point is available in alerts: {}.".format(
                        last_time_alerts
                    )
                )
                self._fetch_alert_data(
                    parameter_alert,
                    state_alerts,
                    armis_alerts,
                    False,
                    last_time_alerts,
                )
                logging.info(
                    "Armis Alert Connecter: Data added when logs was already in %s.",
                    armis_alerts,
                )
            logging.info("Armis Alert Connecter: Alerts data added successfully !")
        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Alert Connecter: Error occured during checking whether log table exist or not."
            )


class AzureSentinel:
    """AzureSentinel is Used to post data to log analytics."""

    def build_signature(
        self,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        """To build the signature."""
        x_headers = "x-ms-date:" + date
        string_to_hash = (
            method
            + "\n"
            + str(content_length)
            + "\n"
            + content_type
            + "\n"
            + x_headers
            + "\n"
            + resource
        )
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
        return authorization

    # Build and send a request to the POST API
    def post_data(self, customer_id, body, log_type):
        """Build and send a request to the POST API."""
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        try:
            signature = self.build_signature(
                rfc1123date,
                content_length,
                method,
                content_type,
                resource,
            )
        except ArmisException as err:
            logging.error("Armis Alert Connecter: Error occured: {}".format(err))
            raise ArmisException(
                "Armis Alert Connecter: Error while generating signature for log analytics."
            )

        uri = (
            "https://"
            + customer_id
            + ".ods.opinsights.azure.com"
            + resource
            + "?api-version=2016-04-01"
        )

        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": log_type,
            "x-ms-date": rfc1123date,
        }
        try:
            response = requests.post(uri, data=body, headers=headers)
            if response.status_code >= 200 and response.status_code <= 299:
                logging.info(
                    "Armis Alert Connecter: Data Posted Successfully to azure setninel."
                )
            else:
                raise ArmisException(
                    "Armis Alert Connecter: Response code: {} from posting data to log analytics.".format(
                        response.status_code
                    )
                )

        except ArmisException as err:
            logging.error(err)
            raise ArmisException(
                "Armis Alert Connecter: Error while posting data to azure sentinel."
            )


def main(mytimer: func.TimerRequest) -> None:
    """This main function will be triggered on specific interval."""
    try:
        utc_timestamp = (
            datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        )
        logging.info(
            "Armis Alert Connecter: Python timer trigger function ran at %s",
            utc_timestamp,
        )

        armis_obj = ArmisAlert()
        armis_obj.check_data_exists_or_not_alert()
        utc_timestamp_final = (
            datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        )
        logging.info(
            "Armis Alert Connecter: Execution Completed for Alerts at %s.",
            utc_timestamp_final,
        )
        if mytimer.past_due:
            logging.info("Armis Alert Connecter: The timer is past due!")
    except ArmisException as err:
        logging.error(err)
